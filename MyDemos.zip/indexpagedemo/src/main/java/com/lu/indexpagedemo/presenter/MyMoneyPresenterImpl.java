package com.lu.indexpagedemo.presenter;
import com.lu.indexpagedemo.base.mvp.BasePresenterImpl;
import com.lu.indexpagedemo.contract.MyMoneyContract;

/**
* Created by 陆正威 on 2017/04/14
*/

public class MyMoneyPresenterImpl extends BasePresenterImpl<MyMoneyContract.View>{

}