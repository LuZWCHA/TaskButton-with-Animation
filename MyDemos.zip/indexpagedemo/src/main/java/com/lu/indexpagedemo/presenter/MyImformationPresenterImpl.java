package com.lu.indexpagedemo.presenter;
import com.lu.indexpagedemo.base.mvp.BasePresenterImpl;

/**
* Created by 陆正威 on 2017/04/11
*/

public class MyImformationPresenterImpl extends BasePresenterImpl{

}