package com.lu.indexpagedemo.presenter;
import com.lu.indexpagedemo.contract.UserCenterContract;
import com.lu.indexpagedemo.base.mvp.BasePresenterImpl;

/**
* Created by 陆正威 on 2017/04/11
*/

public class UserCenterPresenterImpl extends BasePresenterImpl<UserCenterContract.View>{

}