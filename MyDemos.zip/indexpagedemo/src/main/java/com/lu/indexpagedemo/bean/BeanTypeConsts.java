package com.lu.indexpagedemo.bean;

/**
 * Created by 陆正威 on 2017/4/9.
 */

public class BeanTypeConsts {
    public final static int BIGPIC_BEAN = 0x0000;
    public final static int MIDPIC_BEAN = 0x0001;
    public final static int MOREPIC_BEAN = 0x0002;
    public final static int PAGESPICKER_BEAN = 0x0003;
}
