package com.lu.indexpagedemo.base.Tools;

/**
 * Created by 陆正威 on 2017/4/16.
 */

public class Constant {
    public static int screenwithpx;
    public static int screenheightpx;
    public static int screenwithdp;
    public static int screenheightdp;
}
