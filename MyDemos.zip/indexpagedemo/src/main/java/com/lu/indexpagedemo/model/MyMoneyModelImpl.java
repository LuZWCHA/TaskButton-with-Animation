package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.MyMoneyContract;

/**
* Created by 陆正威 on 2017/04/14
*/

public class MyMoneyModelImpl implements MyMoneyContract.Model{

}