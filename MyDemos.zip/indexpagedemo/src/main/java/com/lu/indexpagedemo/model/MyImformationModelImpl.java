package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.MyImformationContract;

/**
* Created by 陆正威 on 2017/04/11
*/

public class MyImformationModelImpl implements MyImformationContract.Model{

}