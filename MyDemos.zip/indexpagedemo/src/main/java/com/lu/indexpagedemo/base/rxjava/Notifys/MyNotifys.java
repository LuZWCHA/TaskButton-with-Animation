package com.lu.indexpagedemo.base.rxjava.Notifys;

import com.lu.indexpagedemo.base.rxjava.Notify;

/**
 * Created by 陆正威 on 2017/4/11.
 */

public class MyNotifys{
    public static class UpdateFinishNotify extends Notify {}
    public static class UpdateNotify extends Notify{
    }
}
