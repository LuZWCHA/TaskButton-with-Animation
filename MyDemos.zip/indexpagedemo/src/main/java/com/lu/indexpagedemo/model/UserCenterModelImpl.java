package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.UserCenterContract;

/**
* Created by 陆正威 on 2017/04/11
*/

public class UserCenterModelImpl implements UserCenterContract.Model{

}