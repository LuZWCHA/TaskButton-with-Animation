package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.CustomContract;

/**
* Created by 陆正威 on 2017/04/12
*/

public class CustomModelImpl implements CustomContract.Model{

}