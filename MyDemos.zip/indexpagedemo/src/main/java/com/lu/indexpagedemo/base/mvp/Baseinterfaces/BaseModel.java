package com.lu.indexpagedemo.base.mvp.Baseinterfaces;

/**
 * Created by 陆正威 on 2017/3/31.
 */

public interface BaseModel {
}
