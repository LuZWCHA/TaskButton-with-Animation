package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.NowMaterialContract;

/**
* Created by 陆正威 on 2017/04/20
*/

public class NowMaterialModelImpl implements NowMaterialContract.Model{

}