package com.lu.indexpagedemo.bean.base.customview;

import android.content.Context;
import android.view.View;

import com.flyco.dialog.widget.popup.BubblePopup;

/**
 * Created by 陆正威 on 2017/4/17.
 */

public class MyBubblePopup extends BubblePopup {
    public MyBubblePopup(Context context, View wrappedView) {
        super(context, wrappedView);
    }
}
