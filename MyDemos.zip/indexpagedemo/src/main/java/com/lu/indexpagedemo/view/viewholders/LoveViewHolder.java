package com.lu.indexpagedemo.view.viewholders;

import android.view.View;

import com.chad.library.adapter.base.BaseViewHolder;

/**
 * Created by 陆正威 on 2017/4/15.
 */

public class LoveViewHolder extends BaseViewHolder {
    public LoveViewHolder(View view) {
        super(view);
    }
}
