package com.lu.indexpagedemo.model;
import com.lu.indexpagedemo.contract.WorkDetailsContract;

/**
* Created by 陆正威 on 2017/04/21
*/

public class WorkDetailsModelImpl implements WorkDetailsContract.Model{

}